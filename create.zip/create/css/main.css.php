<?php
  header('Content-type: text/css');
 ?>

h1 {
  color: rgb( <?php echo rand(0,255); ?> , <?php echo rand(0,255); ?> , <?php echo rand(0,255); ?> );
}

p {
  color: rgb( <?php echo rand(0,255); ?> , <?php echo rand(0,255); ?> , <?php echo rand(0,255); ?> );
}
