<?php

for($i = 5; $i <= 1000000; $i+=5) {
  echo $i . '<br>';
}


?>
